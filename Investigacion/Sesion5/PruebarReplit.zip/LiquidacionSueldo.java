=  public class LiquidacionSueldo {
  
  // private tipoDato nombrePropiedad;
  private Colaborador colaborador;

  // CONSTRUCTOR
  public Colaborador(Colaborador colaborador ){
    this.colaborador = colaborador;
  }

  
  public int calcularMontoImponible(){
    int sueldoBase = this.colaborador.getSueldoBase();
    String horasExtra = this.colaborador.getHorasExtra();
    int sueldoImponible = sueldoBase+horasExtra;
    return sueldoImponible;

    //esas dos parece que son imponibles nomas
    // pero se supone que hay un calculo para sacar el valor de las horas extras
  }

  public int calcularHo
 
  
}