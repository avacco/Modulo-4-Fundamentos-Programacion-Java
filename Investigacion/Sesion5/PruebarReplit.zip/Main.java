´´public class Main {
  public static void main(String[] args) {
    Colaborador[] colaboradores = new Colaborador[]{
      new Colaborador("Santiago Neira", 800000, "modelo", "indefinido", "fonasa", 100000, 0, 0, 0, 100000),
      new Colaborador("Rafael Castillo", 1000000, "cuprum", "indefinido", "fonasa", 100000, 0, 0, 0, 100000),
      new Colaborador("Jessie Uribe", 950000, "habitat", "plazo fijo", "fonasa", 50000, 0, 0, 0, 100000),
      new Colaborador("Diego Padilla", 900000, "uno", "indefinido", "fonasa", 100000, 0, 0, 0, 100000)
    };
    
    for(int i = 0; i < colaboradores.length; i++) {
      LiquidacionSueldo liquiSueldo = new LiquidacionSueldo(colaboradores[i]);
      int montoImponible = liquiSueldo.calcularMontoImponible();
      System.out.printf("Nombre: %s \n", colaboradores[i].getNombre());
      System.out.printf("Monto Imponible: %d \n", montoImponible);
    }

  // por cada colaborador en colaboradores, enviar el objeto con sus datos a los metodos en liquidaciones
  }
}