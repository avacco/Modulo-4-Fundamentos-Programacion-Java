public class Colaborador {
//inicio Propiedades
  private String nombre;
  private int sueldoBase;
  private String afp;
  private String tipoContrato;
  private String salud;
  private int movilizacion;
  private int viaticos;
  private int horasExtra;
  private int asignacionFamiliar;
  private int bonoColacion;

    public class Colaborador(String nombre, int sueldoBase, String afp, String tipoContrato, String salud, int movilizacion, int viaticos, int horasExtra, int asignacionFamiliar, int bonoColacion){
      this.nombre = nombre;
      this.sueldoBase = sueldoBase;
      this.afp = afp;
      this.tipoContrato = tipoContrato;
      this.salud = salud;
      this.movilizacion = movilizacion;
      this.viaticos = viaticos;
      this.horasExtra = horasExtra;
      this.asignacionFamiliar;  
      this.bonoColacion = bonoColacion;
    }

  //constructor vacio
    public class Colaborador(){
  
  }

  // GETTERS 
  public int getMovilizacion(){
    return movilizacion;
  }
  
  public String getTipoContrato(){
    return tipoContrato;
  }

  public String getSalud(){
    return salud;
  }
  
  public String getAfp() {
    return afp;
  }

  public String getNombre() {
    return nombre;
  }

  public int getSueldoBase() {
    return sueldoBase;
    } 
  // SETTERS
  public void String setNombre(String nombre){
    this.nombre = nombre;
  }

  public void int setSueldoBase(int sueldoBase){
    this.sueldoBase = sueldoBase;
  }

  public void String setAfp(String afp){
    this.afp = afp;
  }

  public void String setTipoContrato(String tipoContrato){
    this.tipoContrato = tipoContrato;
  }

  public void String setSalud(String salud){
    this.salud = salud;
  }

  public void int setMovilizacion(int moviliza){
    movilizacion = moviliza;
  }

  public void int setViatico(int viatico){
    viaticos = viatico;
  }

  public void int setHoraExtra(int horaE){
    horaExtra = horaE;
  }
}

